package com.example.photoapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "PhotoApp.db";
    private static final int DATABASE_VERSION = 1;

    // Table name and columns
    private static final String TABLE_PHOTOS = "photos";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_IMAGE_PATH = "image_path";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PHOTOS_TABLE = "CREATE TABLE " + TABLE_PHOTOS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_IMAGE_PATH + " TEXT" + ")";
        db.execSQL(CREATE_PHOTOS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PHOTOS);
        onCreate(db);
    }

    // Add photo
    public long addPhoto(Photo photo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, photo.getName());
        values.put(COLUMN_DESCRIPTION, photo.getDescription());
        values.put(COLUMN_IMAGE_PATH, photo.getImagePath());

        long id = db.insert(TABLE_PHOTOS, null, values);
        db.close();
        return id;
    }

    // Get all photos
    public List<Photo> getAllPhotos() {
        List<Photo> photoList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_PHOTOS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Photo photo = new Photo();
                photo.setId(cursor.getInt(0));
                photo.setName(cursor.getString(1));
                photo.setDescription(cursor.getString(2));
                photo.setImagePath(cursor.getString(3));
                photoList.add(photo);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return photoList;
    }

    // Update photo
    public int updatePhoto(Photo photo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, photo.getName());
        values.put(COLUMN_DESCRIPTION, photo.getDescription());
        values.put(COLUMN_IMAGE_PATH, photo.getImagePath());

        int result = db.update(TABLE_PHOTOS, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(photo.getId())});
        db.close();
        return result;
    }

    // Delete photo
    public void deletePhoto(Photo photo) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PHOTOS, COLUMN_ID + " = ?",
                new String[]{String.valueOf(photo.getId())});
        db.close();
    }
}