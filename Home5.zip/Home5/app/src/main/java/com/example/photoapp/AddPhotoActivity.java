package com.example.photoapp;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class AddPhotoActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PERMISSION_REQUEST_CODE = 100;

    private ImageView imageViewPhoto;
    private EditText editTextName, editTextDescription;
    private Button btnSave, btnCancel;
    private DatabaseHelper databaseHelper;
    private String selectedImagePath = "";
    private boolean isEdit = false;
    private int photoId = -1;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Quyền truy cập bộ nhớ được cấp", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Quyền truy cập bộ nhớ bị từ chối", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_photo);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        imageViewPhoto = findViewById(R.id.imageViewPhoto);
        editTextName = findViewById(R.id.editTextName);
        editTextDescription = findViewById(R.id.editTextDescription);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Check if editing existing photo
        Intent intent = getIntent();
        if (intent.getBooleanExtra("IS_EDIT", false)) {
            isEdit = true;
            photoId = intent.getIntExtra("PHOTO_ID", -1);
            editTextName.setText(intent.getStringExtra("PHOTO_NAME"));
            editTextDescription.setText(intent.getStringExtra("PHOTO_DESCRIPTION"));
            selectedImagePath = intent.getStringExtra("PHOTO_PATH");

            if (selectedImagePath != null && !selectedImagePath.isEmpty()) {
                File imgFile = new File(selectedImagePath);
                if (imgFile.exists()) {
                    Glide.with(this).load(imgFile).into(imageViewPhoto);
                }
            }
        }




        // Button listeners
        imageViewPhoto.setOnClickListener(v -> openImageChooser());
        btnSave.setOnClickListener(v -> savePhoto());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();

            try {
                // Copy image to internal storage
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                String fileName = "photo_" + System.currentTimeMillis() + ".jpg";
                File file = new File(getFilesDir(), fileName);
                FileOutputStream outputStream = new FileOutputStream(file);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }

                inputStream.close();
                outputStream.close();

                selectedImagePath = file.getAbsolutePath();

                // Display image
                Glide.with(this).load(file).into(imageViewPhoto);

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void savePhoto() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter photo name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImagePath.isEmpty()) {
            Toast.makeText(this, "Please select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        Photo photo = new Photo(name, description, selectedImagePath);

        if (isEdit) {
            photo.setId(photoId);
            databaseHelper.updatePhoto(photo);
            Toast.makeText(this, "Photo updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            databaseHelper.addPhoto(photo);
            Toast.makeText(this, "Photo saved successfully", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

}