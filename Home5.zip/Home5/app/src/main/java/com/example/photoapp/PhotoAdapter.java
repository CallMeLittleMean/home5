package com.example.photoapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.io.File;
import java.util.List;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder> {
    private List<Photo> photoList;
    private Context context;
    private DatabaseHelper databaseHelper;

    public PhotoAdapter(Context context, List<Photo> photoList) {
        this.context = context;
        this.photoList = photoList;
        this.databaseHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        Photo photo = photoList.get(position);

        holder.textViewName.setText(photo.getName());
        holder.textViewDescription.setText(photo.getDescription());

        // Load image using Glide
        if (photo.getImagePath() != null && !photo.getImagePath().isEmpty()) {
            File imgFile = new File(photo.getImagePath());
            if (imgFile.exists()) {
                Glide.with(context)
                        .load(imgFile)
                        .into(holder.imageView);
            }
        }

        // Edit button click
        holder.ivEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, AddPhotoActivity.class);
            intent.putExtra("PHOTO_ID", photo.getId());
            intent.putExtra("PHOTO_NAME", photo.getName());
            intent.putExtra("PHOTO_DESCRIPTION", photo.getDescription());
            intent.putExtra("PHOTO_PATH", photo.getImagePath());
            intent.putExtra("IS_EDIT", true);
            context.startActivity(intent);
        });

        // Click on entire item to edit
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, AddPhotoActivity.class);
            intent.putExtra("PHOTO_ID", photo.getId());
            intent.putExtra("PHOTO_NAME", photo.getName());
            intent.putExtra("PHOTO_DESCRIPTION", photo.getDescription());
            intent.putExtra("PHOTO_PATH", photo.getImagePath());
            intent.putExtra("IS_EDIT", true);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    public void removeItem(int position) {
        Photo photo = photoList.get(position);
        databaseHelper.deletePhoto(photo);
        photoList.remove(position);
        notifyItemRemoved(position);
        Toast.makeText(context, "Photo deleted", Toast.LENGTH_SHORT).show();
    }

    public static class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView, ivEdit;
        TextView textViewName, textViewDescription;

        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            ivEdit = itemView.findViewById(R.id.ivEdit);
        }
    }
}