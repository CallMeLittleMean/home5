package com.example.photoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerViewPhotos;
    private PhotoAdapter photoAdapter;
    private DatabaseHelper databaseHelper;
    private List<Photo> photoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        recyclerViewPhotos = findViewById(R.id.recyclerViewPhotos);

        // Setup RecyclerView
        setupRecyclerView();

        // Add photo button click
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddPhotoActivity.class);
            startActivity(intent);
        });

        // Setup swipe to delete
        setupSwipeToDelete();
    }

    private void setupRecyclerView() {
        photoList = databaseHelper.getAllPhotos();
        photoAdapter = new PhotoAdapter(this, photoList);
        recyclerViewPhotos.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPhotos.setAdapter(photoAdapter);
    }

    private void setupSwipeToDelete() {
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                photoAdapter.removeItem(position);
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerViewPhotos);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning from AddPhotoActivity
        photoList.clear();
        photoList.addAll(databaseHelper.getAllPhotos());
        photoAdapter.notifyDataSetChanged();
    }
}
